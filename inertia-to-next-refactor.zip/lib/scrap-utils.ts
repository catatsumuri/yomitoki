export const sourceLabels: Record<string, string> = {
  daily_report: '日報',
  execution: '実行結果',
  inquiry: '問い合わせ',
  meeting_note: '会議メモ',
  plan: '計画',
  research: 'リサーチ',
};

export const statusLabels: Record<string, string> = {
  raw: '未整理',
  queued: 'キュー中',
  final: '最終',
  completed: '完了',
  processed: '処理済',
  failed: '失敗',
  archived: 'アーカイブ',
};

export function toneForStatus(
  status: string
): 'default' | 'secondary' | 'outline' | 'destructive' {
  if (status === 'failed') return 'destructive';
  if (status === 'raw' || status === 'queued') return 'secondary';
  if (status === 'final' || status === 'completed' || status === 'processed') return 'default';
  return 'outline';
}

export function buildFallbackTitle(content: string, currentTitle: string): string {
  const normalizedTitle = currentTitle.trim().replace(/\s+/g, ' ');
  if (normalizedTitle !== '') return normalizedTitle.slice(0, 72);

  const trimmedContent = content.trim();
  const assetMatch = trimmedContent.match(/^!?\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)$/u);

  if (assetMatch) {
    const candidate = (assetMatch[1] || assetMatch[2] || '').trim();
    if (candidate !== '') {
      const withoutQuery = candidate.split('?')[0]?.split('#')[0] ?? candidate;
      const lastSegment = withoutQuery.split('/').pop() ?? withoutQuery;
      const withoutExtension = lastSegment.replace(/\.[^.]+$/u, '');
      const cleaned = withoutExtension.replace(/[-_]+/gu, ' ').trim().replace(/\s+/g, ' ');
      if (cleaned !== '') return cleaned.slice(0, 72);
    }
  }
  return content.trim().replace(/\s+/g, ' ').slice(0, 72);
}

export function buildFallbackSlug(title: string, currentSlug: string): string {
  const source = currentSlug.trim() !== '' ? currentSlug : title;
  return source
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

export function isSupportedBodyFile(file: File): boolean {
  if (file.type.startsWith('image/')) return true;
  const lowerCaseName = file.name.toLowerCase();
  return ['.pdf', '.doc', '.docx', '.md', '.txt'].some((extension) =>
    lowerCaseName.endsWith(extension)
  );
}
