'use client';

import { useState, useCallback, useMemo } from 'react';
import { 
  Archive, 
  ChevronDown, 
  Clock,
  FileText, 
  MoreVertical, 
  Plus, 
  Sparkles, 
  Tag, 
  Trash2,
  X,
  Edit3,
  Eye,
  History,
  Link2,
  Save,
  Undo2,
  Layers,
} from 'lucide-react';
import { AppHeader } from '@/components/app-header';
import { ScrapCard } from '@/components/scrap-card';
import { MarkdownPreview } from '@/components/markdown-preview';
import { DateDisplay } from '@/components/date-display';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { statusLabels, sourceLabels, buildFallbackTitle, buildFallbackSlug } from '@/lib/scrap-utils';
import { cn } from '@/lib/utils';
import type { InboxItem, RelatedScrap } from '@/types';

// Mock data
const mockScraps: InboxItem[] = [
  {
    id: 1,
    parentId: null,
    title: 'Q2マーケティング戦略の見直し',
    slug: 'q2-marketing-strategy',
    content: `# Q2マーケティング戦略

## 目標
- 新規ユーザー獲得 20% 増
- コンバージョン率 5% 向上
- ブランド認知度の拡大

## 施策
1. SNS広告の最適化
2. コンテンツマーケティング強化
3. インフルエンサーとの連携

> 特に重要なのは、ターゲット層に合わせたメッセージングです。

\`\`\`
予算配分:
- SNS広告: 40%
- コンテンツ: 30%
- その他: 30%
\`\`\``,
    sourceType: 'meeting_note',
    status: 'final',
    summary: 'Q2のマーケティング戦略について、SNS広告最適化とコンテンツ強化を中心に議論。',
    tags: ['marketing', 'strategy', 'q2'],
    occurredAt: '2024-03-15T10:00:00Z',
    latestBackup: {
      createdAt: '2024-03-15T12:00:00Z',
      description: '初回バックアップ',
      scrapSlug: 'q2-marketing-strategy',
    },
    children: [],
  },
  {
    id: 2,
    parentId: null,
    title: 'プロダクトロードマップ 2024',
    slug: 'product-roadmap-2024',
    content: `# プロダクトロードマップ 2024

## Q1 (完了)
- ユーザーダッシュボード刷新
- パフォーマンス改善

## Q2 (進行中)
- AI機能の統合
- モバイルアプリのリリース

## Q3 (計画中)
- 企業向け機能拡充
- API v2 リリース`,
    sourceType: 'plan',
    status: 'completed',
    summary: '2024年のプロダクト開発計画。AI統合とモバイルアプリが主要マイルストーン。',
    tags: ['product', 'roadmap', '2024'],
    occurredAt: '2024-03-10T14:30:00Z',
    latestBackup: null,
    children: [
      {
        id: 3,
        parentId: 2,
        title: 'AI機能仕様書',
        sourceType: 'research',
        status: 'processed',
        summary: 'AI機能の詳細仕様',
        occurredAt: '2024-03-12T09:00:00Z',
      },
    ],
  },
  {
    id: 4,
    parentId: null,
    title: null,
    slug: null,
    content: '新しいUIコンポーネントのアイデア: グラスモーフィズムを取り入れたカードデザイン',
    sourceType: 'daily_report',
    status: 'raw',
    summary: null,
    tags: [],
    occurredAt: '2024-03-18T16:45:00Z',
    latestBackup: null,
    children: [],
  },
  {
    id: 5,
    parentId: null,
    title: 'カスタマーサポート改善提案',
    slug: 'customer-support-improvement',
    content: `# カスタマーサポート改善

## 現状の課題
- 応答時間が長い
- FAQの充実度不足
- チャットボットの精度

## 提案
- AIチャットボットの導入
- ナレッジベースの拡充
- サポートチームの増員`,
    sourceType: 'inquiry',
    status: 'queued',
    summary: 'カスタマーサポートの応答時間短縮とAIチャットボット導入の提案。',
    tags: ['support', 'improvement'],
    occurredAt: '2024-03-17T11:20:00Z',
    latestBackup: null,
    children: [],
  },
];

const mockRelatedScraps: RelatedScrap[] = [
  {
    id: 10,
    title: 'Q1マーケティング結果レポート',
    slug: 'q1-marketing-report',
    summary: 'Q1のマーケティング施策の結果と分析',
    status: 'completed',
    sourceType: 'execution',
    occurredAt: '2024-01-31T18:00:00Z',
    similarity: 0.92,
  },
  {
    id: 11,
    title: 'ブランドガイドライン更新',
    slug: 'brand-guidelines-update',
    summary: '新しいブランドガイドラインの概要',
    status: 'final',
    sourceType: 'research',
    occurredAt: '2024-02-15T10:00:00Z',
    similarity: 0.78,
  },
];

const availableTags = ['marketing', 'strategy', 'q2', 'product', 'roadmap', '2024', 'support', 'improvement'];

export default function DashboardPage() {
  const [scraps] = useState<InboxItem[]>(mockScraps);
  const [selectedScrap, setSelectedScrap] = useState<InboxItem | null>(mockScraps[0] ?? null);
  const [relatedScraps] = useState<RelatedScrap[]>(mockRelatedScraps);
  const [activeStatus, setActiveStatus] = useState<'active' | 'archived'>('active');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');
  const [editedTitle, setEditedTitle] = useState('');
  const [editedSlug, setEditedSlug] = useState('');
  const [editedTags, setEditedTags] = useState<string[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showArchiveDialog, setShowArchiveDialog] = useState(false);
  const [rightPanelTab, setRightPanelTab] = useState<'scraps' | 'related'>('scraps');
  const [isSuggestingMetadata, setIsSuggestingMetadata] = useState(false);

  // Filter scraps
  const filteredScraps = useMemo(() => {
    return scraps.filter((scrap) => {
      const statusMatch = activeStatus === 'archived' 
        ? scrap.status === 'archived' 
        : scrap.status !== 'archived';
      const tagMatch = activeTag ? scrap.tags.includes(activeTag) : true;
      return statusMatch && tagMatch;
    });
  }, [scraps, activeStatus, activeTag]);

  // Start editing
  const handleStartEdit = useCallback(() => {
    if (!selectedScrap) return;
    setEditedContent(selectedScrap.content);
    setEditedTitle(selectedScrap.title ?? '');
    setEditedSlug(selectedScrap.slug ?? '');
    setEditedTags([...selectedScrap.tags]);
    setIsEditing(true);
  }, [selectedScrap]);

  // Cancel editing
  const handleCancelEdit = useCallback(() => {
    setIsEditing(false);
    setEditedContent('');
    setEditedTitle('');
    setEditedSlug('');
    setEditedTags([]);
  }, []);

  // Save changes (mock)
  const handleSave = useCallback(() => {
    // In a real app, this would call an API
    console.log('Saving:', { editedTitle, editedSlug, editedContent, editedTags });
    setIsEditing(false);
  }, [editedTitle, editedSlug, editedContent, editedTags]);

  // AI metadata suggestion (mock)
  const handleSuggestMetadata = useCallback(async () => {
    setIsSuggestingMetadata(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    const suggestedTitle = buildFallbackTitle(editedContent, editedTitle);
    const suggestedSlug = buildFallbackSlug(suggestedTitle, editedSlug);
    setEditedTitle(suggestedTitle);
    setEditedSlug(suggestedSlug);
    setIsSuggestingMetadata(false);
  }, [editedContent, editedTitle, editedSlug]);

  // Add/remove tag
  const handleToggleTag = useCallback((tag: string) => {
    setEditedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  }, []);

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background">
        <AppHeader />
        
        <main className="mx-auto max-w-7xl px-4 py-6 md:px-6">
          {/* Page Header */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-foreground">
                スクラップ
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                あなたのナレッジを整理・管理します
              </p>
            </div>
            <Button className="gap-2 rounded-xl shadow-lg shadow-primary/20">
              <Plus className="size-4" />
              新規スクラップ
            </Button>
          </div>

          {/* Filters */}
          <div className="mb-6 flex flex-wrap items-center gap-3">
            <Tabs 
              value={activeStatus} 
              onValueChange={(v) => setActiveStatus(v as 'active' | 'archived')}
              className="w-auto"
            >
              <TabsList className="h-10 rounded-xl bg-muted/50 p-1">
                <TabsTrigger 
                  value="active" 
                  className="rounded-lg px-4 data-[state=active]:bg-background data-[state=active]:shadow-sm"
                >
                  <FileText className="mr-2 size-4" />
                  アクティブ
                </TabsTrigger>
                <TabsTrigger 
                  value="archived"
                  className="rounded-lg px-4 data-[state=active]:bg-background data-[state=active]:shadow-sm"
                >
                  <Archive className="mr-2 size-4" />
                  アーカイブ
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <Separator orientation="vertical" className="h-6 hidden sm:block" />

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                <Tag className="size-3.5" />
                タグ:
              </span>
              <Button
                variant={activeTag === null ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setActiveTag(null)}
                className="h-7 rounded-lg text-xs"
              >
                すべて
              </Button>
              {availableTags.slice(0, 5).map((tag) => (
                <Button
                  key={tag}
                  variant={activeTag === tag ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveTag(tag === activeTag ? null : tag)}
                  className="h-7 rounded-lg text-xs"
                >
                  #{tag}
                </Button>
              ))}
              {availableTags.length > 5 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-7 rounded-lg text-xs">
                      +{availableTags.length - 5}
                      <ChevronDown className="ml-1 size-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {availableTags.slice(5).map((tag) => (
                      <DropdownMenuItem
                        key={tag}
                        onClick={() => setActiveTag(tag === activeTag ? null : tag)}
                      >
                        #{tag}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>

          {/* Main Content Grid - 2 Pane Layout */}
          <div className="grid gap-6 lg:grid-cols-12">
            {/* Left Pane - Detail / Editor */}
            <div className="lg:col-span-7 xl:col-span-8">
              {selectedScrap ? (
                <div className="rounded-2xl border border-border/50 bg-card/50 shadow-sm">
                  {/* Detail Header */}
                  <div className="flex items-center justify-between border-b border-border/50 px-5 py-4">
                    <div className="flex items-center gap-3">
                      {isEditing ? (
                        <Badge variant="outline" className="gap-1.5 text-primary border-primary/30 px-3 py-1">
                          <Edit3 className="size-3" />
                          編集中
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="gap-1.5 px-3 py-1">
                          <Eye className="size-3" />
                          プレビュー
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs">
                        {sourceLabels[selectedScrap.sourceType] ?? selectedScrap.sourceType}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1">
                      {isEditing ? (
                        <>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={handleCancelEdit}
                                className="size-9 rounded-xl"
                              >
                                <Undo2 className="size-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>キャンセル</TooltipContent>
                          </Tooltip>
                          <Button
                            size="sm"
                            onClick={handleSave}
                            className="gap-1.5 rounded-xl px-4"
                          >
                            <Save className="size-3.5" />
                            保存
                          </Button>
                        </>
                      ) : (
                        <>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={handleStartEdit}
                                className="size-9 rounded-xl"
                              >
                                <Edit3 className="size-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>編集</TooltipContent>
                          </Tooltip>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-9 rounded-xl">
                                <MoreVertical className="size-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setShowArchiveDialog(true)}>
                                <Archive className="mr-2 size-4" />
                                アーカイブ
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => setShowDeleteDialog(true)}
                                className="text-destructive"
                              >
                                <Trash2 className="mr-2 size-4" />
                                削除
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Content Area */}
                  <ScrollArea className="h-[calc(100vh-18rem)]">
                    <div className="p-6">
                      {isEditing ? (
                        <div className="space-y-6">
                          {/* Metadata Section */}
                          <div className="space-y-4 rounded-xl border border-border/50 bg-muted/30 p-5">
                            <div className="flex items-center justify-between">
                              <h3 className="text-sm font-medium text-foreground">メタデータ</h3>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={handleSuggestMetadata}
                                disabled={isSuggestingMetadata}
                                className="gap-1.5 rounded-xl text-xs h-8"
                              >
                                <Sparkles className={cn(
                                  "size-3",
                                  isSuggestingMetadata && "animate-pulse"
                                )} />
                                {isSuggestingMetadata ? 'AI生成中...' : 'AIで提案'}
                              </Button>
                            </div>
                            <div className="grid gap-4 sm:grid-cols-2">
                              <div>
                                <label className="text-xs text-muted-foreground mb-1.5 block">タイトル</label>
                                <Input
                                  value={editedTitle}
                                  onChange={(e) => setEditedTitle(e.target.value)}
                                  placeholder="タイトルを入力..."
                                  className="rounded-xl bg-background/50"
                                />
                              </div>
                              <div>
                                <label className="text-xs text-muted-foreground mb-1.5 block">スラッグ</label>
                                <Input
                                  value={editedSlug}
                                  onChange={(e) => setEditedSlug(e.target.value)}
                                  placeholder="slug-example"
                                  className="rounded-xl bg-background/50 font-mono text-sm"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Tags Section */}
                          <div className="space-y-3">
                            <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                              <Tag className="size-4" />
                              タグ
                            </h3>
                            <div className="flex flex-wrap gap-2">
                              {availableTags.map((tag) => (
                                <Badge
                                  key={tag}
                                  variant={editedTags.includes(tag) ? 'default' : 'outline'}
                                  className={cn(
                                    "cursor-pointer transition-all rounded-lg",
                                    editedTags.includes(tag) 
                                      ? "bg-primary/20 text-primary hover:bg-primary/30" 
                                      : "hover:border-primary/50"
                                  )}
                                  onClick={() => handleToggleTag(tag)}
                                >
                                  #{tag}
                                  {editedTags.includes(tag) && (
                                    <X className="ml-1 size-3" />
                                  )}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          {/* Content Editor */}
                          <div className="space-y-3">
                            <h3 className="text-sm font-medium text-foreground">コンテンツ</h3>
                            <Textarea
                              value={editedContent}
                              onChange={(e) => setEditedContent(e.target.value)}
                              placeholder="Markdown形式で記述..."
                              className="min-h-[400px] rounded-xl bg-background/50 font-mono text-sm leading-relaxed resize-none"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {/* Title & Meta */}
                          <div>
                            <h2 className="text-2xl font-bold text-foreground">
                              {selectedScrap.title ?? '無題のスクラップ'}
                            </h2>
                            <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1.5">
                                <Clock className="size-4" />
                                <DateDisplay value={selectedScrap.occurredAt} />
                              </span>
                              {selectedScrap.latestBackup && (
                                <span className="flex items-center gap-1.5">
                                  <History className="size-4" />
                                  最終バックアップ: <DateDisplay value={selectedScrap.latestBackup.createdAt} />
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Tags */}
                          {selectedScrap.tags.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {selectedScrap.tags.map((tag) => (
                                <Badge 
                                  key={tag} 
                                  variant="secondary"
                                  className="text-xs rounded-lg px-2.5 py-0.5"
                                >
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                          )}

                          {/* Summary */}
                          {selectedScrap.summary && (
                            <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
                              <p className="text-sm leading-relaxed text-foreground/80">
                                {selectedScrap.summary}
                              </p>
                            </div>
                          )}

                          <Separator className="bg-border/50" />

                          {/* Content Preview */}
                          <MarkdownPreview content={selectedScrap.content} />
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              ) : (
                <div className="flex h-[calc(100vh-14rem)] items-center justify-center rounded-2xl border border-dashed border-border/50 bg-card/20">
                  <div className="text-center">
                    <FileText className="mx-auto size-16 text-muted-foreground/20" />
                    <p className="mt-4 text-muted-foreground">
                      スクラップを選択してください
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground/60">
                      右のパネルからスクラップを選択
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Right Pane - Scraps List & Related */}
            <div className="lg:col-span-5 xl:col-span-4">
              <div className="rounded-2xl border border-border/50 bg-card/50 shadow-sm">
                {/* Tab Navigation */}
                <Tabs value={rightPanelTab} onValueChange={(v) => setRightPanelTab(v as 'scraps' | 'related')}>
                  <div className="border-b border-border/50 px-4 pt-3">
                    <TabsList className="h-10 w-full bg-muted/50 rounded-xl p-1">
                      <TabsTrigger 
                        value="scraps" 
                        className="flex-1 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm gap-2"
                      >
                        <Layers className="size-4" />
                        スクラップ
                        <Badge variant="secondary" className="ml-1 text-[10px] h-5">
                          {filteredScraps.length}
                        </Badge>
                      </TabsTrigger>
                      <TabsTrigger 
                        value="related"
                        className="flex-1 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm gap-2"
                      >
                        <Link2 className="size-4" />
                        関連
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  {/* Scraps Tab Content */}
                  <TabsContent value="scraps" className="m-0">
                    <ScrollArea className="h-[calc(100vh-18rem)]">
                      <div className="space-y-2 p-3">
                        {filteredScraps.map((scrap) => (
                          <ScrapCard
                            key={scrap.id}
                            item={scrap}
                            isSelected={selectedScrap?.id === scrap.id}
                            onClick={() => {
                              setSelectedScrap(scrap);
                              if (isEditing) handleCancelEdit();
                            }}
                            compact
                          />
                        ))}
                        {filteredScraps.length === 0 && (
                          <div className="flex flex-col items-center justify-center py-16 text-center">
                            <FileText className="size-12 text-muted-foreground/20" />
                            <p className="mt-4 text-sm text-muted-foreground">
                              スクラップがありません
                            </p>
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  {/* Related Tab Content */}
                  <TabsContent value="related" className="m-0">
                    <ScrollArea className="h-[calc(100vh-18rem)]">
                      <div className="p-3 space-y-4">
                        {/* Related Scraps Section */}
                        <div className="space-y-2">
                          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1 flex items-center gap-2">
                            <Link2 className="size-3.5" />
                            関連スクラップ
                          </h3>
                          {relatedScraps.length > 0 ? (
                            <div className="space-y-2">
                              {relatedScraps.map((related) => (
                                <button
                                  key={related.id}
                                  type="button"
                                  className="w-full text-left rounded-xl border border-border/50 bg-background/50 p-4 transition-all hover:border-primary/30 hover:shadow-md"
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <p className="text-sm font-medium text-foreground truncate">
                                      {related.title}
                                    </p>
                                    <Badge variant="outline" className="text-[10px] shrink-0 rounded-lg">
                                      {Math.round(related.similarity * 100)}%
                                    </Badge>
                                  </div>
                                  {related.summary && (
                                    <p className="mt-2 text-xs text-muted-foreground line-clamp-2">
                                      {related.summary}
                                    </p>
                                  )}
                                </button>
                              ))}
                            </div>
                          ) : (
                            <p className="py-6 text-center text-xs text-muted-foreground">
                              関連するスクラップがありません
                            </p>
                          )}
                        </div>

                        {/* Backup History Section */}
                        {selectedScrap?.latestBackup && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1 flex items-center gap-2">
                              <History className="size-3.5" />
                              バックアップ
                            </h3>
                            <div className="rounded-xl border border-border/50 bg-background/50 p-4">
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-muted-foreground">最新</span>
                                <span className="text-xs text-muted-foreground tabular-nums">
                                  <DateDisplay value={selectedScrap.latestBackup.createdAt} />
                                </span>
                              </div>
                              {selectedScrap.latestBackup.description && (
                                <p className="mt-2 text-sm text-foreground">
                                  {selectedScrap.latestBackup.description}
                                </p>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Children Section */}
                        {selectedScrap && selectedScrap.children.length > 0 && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1 flex items-center gap-2">
                              <FileText className="size-3.5" />
                              子スクラップ
                              <Badge variant="secondary" className="ml-auto text-[10px]">
                                {selectedScrap.children.length}
                              </Badge>
                            </h3>
                            <div className="space-y-2">
                              {selectedScrap.children.map((child) => (
                                <button
                                  key={child.id}
                                  type="button"
                                  className="w-full text-left rounded-xl border border-border/50 bg-background/50 p-4 transition-all hover:border-primary/30"
                                >
                                  <p className="text-sm font-medium text-foreground truncate">
                                    {child.title ?? '無題'}
                                  </p>
                                  <p className="mt-1 text-xs text-muted-foreground">
                                    {statusLabels[child.status] ?? child.status}
                                  </p>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Empty state for related tab when no scrap selected */}
                        {!selectedScrap && (
                          <div className="flex flex-col items-center justify-center py-16 text-center">
                            <Link2 className="size-12 text-muted-foreground/20" />
                            <p className="mt-4 text-sm text-muted-foreground">
                              スクラップを選択すると
                            </p>
                            <p className="text-sm text-muted-foreground">
                              関連情報が表示されます
                            </p>
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </main>

        {/* Delete Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent className="rounded-2xl">
            <DialogHeader>
              <DialogTitle>スクラップを削除</DialogTitle>
              <DialogDescription>
                この操作は取り消せません。本当に削除しますか？
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
                キャンセル
              </Button>
              <Button variant="destructive" onClick={() => setShowDeleteDialog(false)}>
                削除する
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Archive Dialog */}
        <Dialog open={showArchiveDialog} onOpenChange={setShowArchiveDialog}>
          <DialogContent className="rounded-2xl">
            <DialogHeader>
              <DialogTitle>スクラップをアーカイブ</DialogTitle>
              <DialogDescription>
                アーカイブしたスクラップは「アーカイブ」タブから確認できます。
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowArchiveDialog(false)}>
                キャンセル
              </Button>
              <Button onClick={() => setShowArchiveDialog(false)}>
                アーカイブする
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
