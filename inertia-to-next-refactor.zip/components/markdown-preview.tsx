'use client';

import { Fragment } from 'react';

function renderInlineMarkdown(text: string): React.ReactNode {
  const fragments: React.ReactNode[] = [];
  const pattern = /(`[^`]+`|\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  match = pattern.exec(text);
  while (match !== null) {
    if (match.index > lastIndex) {
      fragments.push(text.slice(lastIndex, match.index));
    }
    const token = match[0];
    if (token.startsWith('`') && token.endsWith('`')) {
      fragments.push(
        <code
          key={`code-${match.index}`}
          className="rounded-lg bg-primary/10 px-1.5 py-0.5 text-[0.9em] font-mono text-primary"
        >
          {token.slice(1, -1)}
        </code>
      );
    } else if (token.startsWith('**') && token.endsWith('**')) {
      fragments.push(
        <strong key={`strong-${match.index}`} className="font-semibold text-foreground">
          {token.slice(2, -2)}
        </strong>
      );
    } else {
      const linkMatch = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(token);
      if (linkMatch) {
        fragments.push(
          <a
            key={`link-${match.index}`}
            href={linkMatch[2]}
            target="_blank"
            rel="noreferrer"
            className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
          >
            {linkMatch[1]}
          </a>
        );
      } else {
        fragments.push(token);
      }
    }
    lastIndex = match.index + token.length;
    match = pattern.exec(text);
  }

  if (lastIndex < text.length) {
    fragments.push(text.slice(lastIndex));
  }

  return fragments.map((fragment, index) => (
    <Fragment key={index}>{fragment}</Fragment>
  ));
}

export function MarkdownPreview({ content }: { content: string }) {
  const lines = content.split('\n');
  const nodes: React.ReactNode[] = [];
  let listItems: string[] = [];
  let orderedListItems: string[] = [];
  let quoteLines: string[] = [];
  let codeLines: string[] = [];
  let inCodeBlock = false;

  const flushList = (): void => {
    if (listItems.length === 0) return;
    nodes.push(
      <ul key={`list-${nodes.length}`} className="list-disc space-y-1.5 pl-6 marker:text-primary/50">
        {listItems.map((item, index) => (
          <li key={index} className="pl-1">{renderInlineMarkdown(item)}</li>
        ))}
      </ul>
    );
    listItems = [];
  };

  const flushQuote = (): void => {
    if (quoteLines.length === 0) return;
    nodes.push(
      <blockquote
        key={`quote-${nodes.length}`}
        className="border-l-2 border-primary/30 pl-4 text-muted-foreground italic"
      >
        {quoteLines.map((line, index) => (
          <p key={index}>{renderInlineMarkdown(line)}</p>
        ))}
      </blockquote>
    );
    quoteLines = [];
  };

  const flushOrderedList = (): void => {
    if (orderedListItems.length === 0) return;
    nodes.push(
      <ol key={`ordered-list-${nodes.length}`} className="list-decimal space-y-1.5 pl-6 marker:text-primary/50">
        {orderedListItems.map((item, index) => (
          <li key={index} className="pl-1">{renderInlineMarkdown(item)}</li>
        ))}
      </ol>
    );
    orderedListItems = [];
  };

  const flushCodeBlock = (): void => {
    if (codeLines.length === 0) return;
    nodes.push(
      <pre
        key={`code-${nodes.length}`}
        className="overflow-x-auto rounded-xl bg-muted/50 border border-border/50 px-4 py-3 text-sm font-mono"
      >
        <code className="text-foreground/90">{codeLines.join('\n')}</code>
      </pre>
    );
    codeLines = [];
  };

  for (const line of lines) {
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        flushCodeBlock();
        inCodeBlock = false;
      } else {
        flushList();
        flushOrderedList();
        flushQuote();
        inCodeBlock = true;
      }
      continue;
    }
    if (inCodeBlock) {
      codeLines.push(line);
      continue;
    }
    if (line.startsWith('- ')) {
      flushQuote();
      flushOrderedList();
      listItems.push(line.slice(2));
      continue;
    }
    if (/^\d+\.\s/.test(line)) {
      flushList();
      flushQuote();
      orderedListItems.push(line.replace(/^\d+\.\s/, ''));
      continue;
    }
    if (line.startsWith('> ')) {
      flushList();
      flushOrderedList();
      quoteLines.push(line.slice(2));
      continue;
    }
    flushList();
    flushOrderedList();
    flushQuote();
    if (line.trim() === '') {
      nodes.push(<div key={`space-${nodes.length}`} className="h-3" />);
      continue;
    }
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(line.trim())) {
      nodes.push(
        <hr key={`hr-${nodes.length}`} className="border-border/50 my-4" />
      );
      continue;
    }
    if (line.startsWith('### ')) {
      nodes.push(
        <h3 key={`h3-${nodes.length}`} className="text-lg font-semibold text-foreground mt-4">
          {renderInlineMarkdown(line.slice(4))}
        </h3>
      );
      continue;
    }
    if (line.startsWith('## ')) {
      nodes.push(
        <h2 key={`h2-${nodes.length}`} className="text-xl font-semibold text-foreground mt-4">
          {renderInlineMarkdown(line.slice(3))}
        </h2>
      );
      continue;
    }
    if (line.startsWith('# ')) {
      nodes.push(
        <h1 key={`h1-${nodes.length}`} className="text-2xl font-bold text-foreground mt-4">
          {renderInlineMarkdown(line.slice(2))}
        </h1>
      );
      continue;
    }
    nodes.push(
      <p key={`p-${nodes.length}`} className="leading-7 text-foreground/90">
        {renderInlineMarkdown(line)}
      </p>
    );
  }

  flushList();
  flushOrderedList();
  flushQuote();
  flushCodeBlock();

  return <div className="space-y-3 text-sm">{nodes}</div>;
}
