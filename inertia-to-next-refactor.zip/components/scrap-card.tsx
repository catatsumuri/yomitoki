'use client';

import { Badge } from '@/components/ui/badge';
import { DateDisplay } from '@/components/date-display';
import { toneForStatus, statusLabels, sourceLabels } from '@/lib/scrap-utils';
import { cn } from '@/lib/utils';
import type { InboxItem } from '@/types';

type ScrapCardProps = {
  item: InboxItem;
  isSelected?: boolean;
  onClick?: () => void;
  compact?: boolean;
};

export function ScrapCard({ item, isSelected, onClick, compact = false }: ScrapCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'group relative w-full text-left rounded-2xl border p-4 transition-all duration-200',
        'bg-card/50 backdrop-blur-sm hover:bg-card hover:border-primary/30',
        isSelected
          ? 'border-primary/50 ring-2 ring-primary/20 bg-card shadow-lg shadow-primary/5'
          : 'border-border/50 hover:shadow-lg hover:shadow-black/5'
      )}
    >
      {/* Glow effect on hover */}
      <div className={cn(
        'absolute inset-0 rounded-2xl opacity-0 transition-opacity',
        'bg-gradient-to-br from-primary/5 via-transparent to-transparent',
        'group-hover:opacity-100'
      )} />
      
      <div className="relative">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <p className={cn(
              'font-medium text-foreground truncate',
              compact ? 'text-sm' : 'text-base'
            )}>
              {item.title ?? '無題のスクラップ'}
            </p>
            <p className={cn(
              'mt-1 text-muted-foreground line-clamp-2',
              compact ? 'text-xs leading-relaxed' : 'text-sm leading-6'
            )}>
              {item.summary ?? 'まだサマリーがありません。これはまだ未整理のキャプチャです。'}
            </p>
          </div>
          <Badge 
            variant={toneForStatus(item.status)}
            className={cn(
              'shrink-0 font-medium',
              toneForStatus(item.status) === 'default' && 'bg-primary/20 text-primary hover:bg-primary/30'
            )}
          >
            {statusLabels[item.status] ?? item.status}
          </Badge>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <span className="size-1.5 rounded-full bg-primary/40" />
            {sourceLabels[item.sourceType] ?? item.sourceType}
          </span>
          {item.tags.map((tag) => (
            <Badge 
              key={tag} 
              variant="outline" 
              className="text-[10px] px-1.5 py-0 h-5 border-border/50 text-muted-foreground"
            >
              #{tag}
            </Badge>
          ))}
          <span className="text-border">•</span>
          <span className="tabular-nums">
            <DateDisplay value={item.occurredAt} />
          </span>
        </div>
      </div>
    </button>
  );
}
