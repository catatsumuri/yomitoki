export type BreadcrumbItem = {
  title: string;
  href: string;
};

export type NavItem = {
  title: string;
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
};

export type InboxItem = {
  id: number;
  parentId: number | null;
  title: string | null;
  slug: string | null;
  content: string;
  sourceType: string;
  status: string;
  summary: string | null;
  tags: string[];
  occurredAt: string | null;
  latestBackup: {
    createdAt: string;
    description: string | null;
    scrapSlug: string;
  } | null;
  children: {
    id: number;
    parentId: number | null;
    title: string | null;
    sourceType: string;
    status: string;
    summary: string | null;
    occurredAt: string | null;
  }[];
};

export type RelatedScrap = {
  id: number;
  title: string | null;
  slug: string | null;
  summary: string | null;
  status: string;
  sourceType: string;
  occurredAt: string | null;
  similarity: number;
};

export type DashboardData = {
  inboxItems: InboxItem[];
  selectedScrap: InboxItem | null;
  relatedScraps: RelatedScrap[];
  availableTags: string[];
  activeTag: string | null;
  activeStatus: 'active' | 'archived';
};
