"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";

const features = [
  "プランが自動で流れ込む（Claude Code 連携）",
  "類似プランを即座に検索",
  "承認後も文脈が残る",
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.3,
    },
  },
};

const item = {
  hidden: { opacity: 0, x: -20 },
  show: { opacity: 1, x: 0 },
};

export function FeatureList() {
  return (
    <motion.ul
      className="mb-8 flex flex-col gap-4"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {features.map((text, i) => (
        <motion.li
          key={i}
          variants={item}
          className="flex items-start gap-3 group"
        >
          <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#CEBCA6] to-[#a89a7a] shadow-sm group-hover:shadow-md group-hover:shadow-[#CEBCA6]/20 transition-all duration-300">
            <Check className="h-3 w-3 text-[#0C2334]" strokeWidth={3} />
          </span>
          <span className="text-sm text-[#1b1b18] dark:text-[#EDEDEC] group-hover:text-[#0C2334] dark:group-hover:text-white transition-colors duration-300">
            {text}
          </span>
        </motion.li>
      ))}
    </motion.ul>
  );
}
