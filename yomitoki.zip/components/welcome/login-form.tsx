"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { KeyRound } from "lucide-react";
import InputError from "@/components/input-error";
import PasswordInput from "@/components/password-input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

type Props = {
  canResetPassword?: boolean;
  status?: string;
};

export function LoginForm({ canResetPassword = true, status }: Props) {
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsLoading(false);
    
    // For demo purposes - show success message
    alert("ログインフォームのデモです。実際のInertia.js環境で使用してください。");
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="flex flex-col gap-5"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      {status && (
        <motion.p
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-sm font-medium text-green-600 bg-green-50 dark:bg-green-950/30 px-4 py-2 rounded-lg"
        >
          {status}
        </motion.p>
      )}
      
      <div className="grid gap-2">
        <Label htmlFor="email" className="text-[#1b1b18] dark:text-[#EDEDEC]">
          メールアドレス
        </Label>
        <Input
          id="email"
          type="email"
          name="email"
          required
          autoFocus
          tabIndex={1}
          autoComplete="email"
          placeholder="email@example.com"
          className="bg-white/50 dark:bg-[#1f1f1e] border-[#e3e3e0] dark:border-[#3E3E3A] focus:border-[#CEBCA6] focus:ring-[#CEBCA6]/20 transition-all duration-300"
        />
        <InputError message={errors.email} />
      </div>
      
      <div className="grid gap-2">
        <div className="flex items-center">
          <Label htmlFor="password" className="text-[#1b1b18] dark:text-[#EDEDEC]">
            パスワード
          </Label>
          {canResetPassword && (
            <a
              href="#"
              className="ml-auto text-xs text-[#706f6c] underline-offset-4 hover:underline hover:text-[#CEBCA6] dark:text-[#A1A09A] transition-colors duration-200"
              tabIndex={5}
            >
              パスワードをお忘れですか？
            </a>
          )}
        </div>
        <PasswordInput
          id="password"
          name="password"
          required
          tabIndex={2}
          autoComplete="current-password"
          placeholder="パスワード"
          className="bg-white/50 dark:bg-[#1f1f1e] border-[#e3e3e0] dark:border-[#3E3E3A] focus:border-[#CEBCA6] focus:ring-[#CEBCA6]/20 transition-all duration-300"
        />
        <InputError message={errors.password} />
      </div>
      
      <div className="flex items-center space-x-3">
        <Checkbox id="remember" name="remember" tabIndex={3} className="border-[#e3e3e0] dark:border-[#3E3E3A] data-[state=checked]:bg-[#0C2334] data-[state=checked]:border-[#0C2334]" />
        <Label htmlFor="remember" className="text-sm text-[#706f6c] dark:text-[#A1A09A] cursor-pointer">
          ログイン状態を保持する
        </Label>
      </div>
      
      <Button
        type="submit"
        tabIndex={4}
        disabled={isLoading}
        className="w-full bg-[#0C2334] hover:bg-[#1a3a4f] text-white shadow-lg shadow-[#0C2334]/20 hover:shadow-xl hover:shadow-[#0C2334]/30 transition-all duration-300 disabled:opacity-70"
      >
        {isLoading ? (
          <motion.div
            className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        ) : null}
        {isLoading ? "ログイン中..." : "ログイン"}
      </Button>

      {/* Passkey separator */}
      <div className="relative my-2">
        <div className="absolute inset-0 flex items-center">
          <Separator className="w-full bg-[#e3e3e0] dark:bg-[#3E3E3A]" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-white dark:bg-[#161615] px-3 text-[#706f6c] dark:text-[#A1A09A]">
            または
          </span>
        </div>
      </div>

      <Button
        type="button"
        variant="outline"
        className="w-full border-[#e3e3e0] dark:border-[#3E3E3A] hover:bg-[#f5f5f4] dark:hover:bg-[#1f1f1e] hover:border-[#CEBCA6] transition-all duration-300"
      >
        <KeyRound className="h-4 w-4 mr-2" />
        パスキーでログイン
      </Button>
    </motion.form>
  );
}
