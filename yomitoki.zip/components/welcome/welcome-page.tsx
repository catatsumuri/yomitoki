'use client';

import { RadicalWelcome } from './radical-welcome';

type Props = {
  canResetPassword?: boolean;
  status?: string;
  isLoggedIn?: boolean;
};

export function WelcomePage({ canResetPassword = true, status, isLoggedIn = false }: Props) {
  return <RadicalWelcome />;
}
