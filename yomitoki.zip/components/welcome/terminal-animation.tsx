"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const terminalLines = [
  { type: "command", content: "$ /plan" },
  { type: "comment", content: "# ExitPlanMode 承認済" },
  { type: "command", content: "$ save-plan.sh" },
  { type: "success", content: "✓ Saved to scraps (plan)" },
];

const inboxItems = [
  {
    name: "welcome-page-redesign",
    status: "new",
    time: "just now",
  },
  {
    name: "embedding-vector-strategy",
    status: "old",
    time: "2 days ago",
  },
  {
    name: "plan-to-markdown-skill",
    status: "archived",
    time: "5 days ago",
  },
];

export function TerminalAnimation() {
  const [visibleLines, setVisibleLines] = useState(0);
  const [showInbox, setShowInbox] = useState(false);
  const [visibleInboxItems, setVisibleInboxItems] = useState(0);

  useEffect(() => {
    const lineTimer = setInterval(() => {
      setVisibleLines((prev) => {
        if (prev >= terminalLines.length) {
          clearInterval(lineTimer);
          setTimeout(() => setShowInbox(true), 400);
          return prev;
        }
        return prev + 1;
      });
    }, 600);

    return () => clearInterval(lineTimer);
  }, []);

  useEffect(() => {
    if (!showInbox) return;
    const itemTimer = setInterval(() => {
      setVisibleInboxItems((prev) => {
        if (prev >= inboxItems.length) {
          clearInterval(itemTimer);
          return prev;
        }
        return prev + 1;
      });
    }, 300);

    return () => clearInterval(itemTimer);
  }, [showInbox]);

  return (
    <div className="absolute inset-4 md:inset-6 flex flex-col rounded-xl border border-[#2a2a28] bg-[#161615]/95 shadow-2xl backdrop-blur-sm overflow-hidden">
      {/* Title bar */}
      <div className="flex shrink-0 items-center gap-2 border-b border-[#2a2a28] px-4 py-3 bg-[#1a1a19]">
        <div className="flex gap-1.5">
          <span className="h-3 w-3 rounded-full bg-[#ff5f57] shadow-[0_0_8px_rgba(255,95,87,0.3)]" />
          <span className="h-3 w-3 rounded-full bg-[#febc2e] shadow-[0_0_8px_rgba(254,188,46,0.3)]" />
          <span className="h-3 w-3 rounded-full bg-[#28c840] shadow-[0_0_8px_rgba(40,200,64,0.3)]" />
        </div>
        <span className="ml-3 font-mono text-xs text-[#706f6c]">
          yomitoki — bash
        </span>
      </div>

      {/* Terminal content */}
      <div className="flex-1 overflow-hidden px-4 md:px-5 py-4 font-mono text-xs md:text-sm leading-6 md:leading-7">
        {terminalLines.slice(0, visibleLines).map((line, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {line.type === "command" && (
              <p>
                <span className="text-[#28c840]">$</span>
                <span className="ml-2 text-[#EDEDEC]">{line.content.slice(2)}</span>
                {i === visibleLines - 1 && (
                  <motion.span
                    className="ml-1 inline-block w-2 h-4 bg-[#28c840]"
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                )}
              </p>
            )}
            {line.type === "comment" && (
              <p className="ml-4 text-[#706f6c]">{line.content}</p>
            )}
            {line.type === "success" && (
              <p className="ml-4 text-[#28c840]">{line.content}</p>
            )}
          </motion.div>
        ))}

        {showInbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            <div className="my-4 border-t border-[#2a2a28]" />
            <p className="mb-3 text-xs text-[#706f6c]"># inbox</p>

            {inboxItems.slice(0, visibleInboxItems).map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`mb-2 rounded-lg border px-3 py-2 transition-all duration-300 ${
                  item.status === "new"
                    ? "border-[#3E3E3A] bg-[#1f1f1e] shadow-[0_0_20px_rgba(40,200,64,0.1)]"
                    : item.status === "archived"
                    ? "border-[#2a2a28] opacity-40"
                    : "border-[#2a2a28]"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`truncate ${
                      item.status === "new" ? "text-[#EDEDEC]" : "text-[#A1A09A]"
                    }`}
                  >
                    {item.name}
                  </span>
                  <span
                    className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] ${
                      item.status === "new"
                        ? "bg-[#28c840]/20 text-[#28c840]"
                        : "bg-[#A1A09A]/20 text-[#A1A09A]"
                    }`}
                  >
                    plan
                  </span>
                </div>
                <p className="mt-0.5 text-[10px] text-[#706f6c]">{item.time}</p>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>

      {/* Glow effect */}
      <div className="absolute inset-0 rounded-xl pointer-events-none bg-gradient-to-t from-[#28c840]/5 to-transparent" />
    </div>
  );
}
