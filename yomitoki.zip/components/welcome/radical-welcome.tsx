'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Sun, Moon, ArrowRight } from 'lucide-react';
import Image from 'next/image';

export function RadicalWelcome() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isDark, setIsDark] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1000);
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden relative">
      {/* Floating accents */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute w-[600px] h-[600px] rounded-full"
          style={{
            background: 'radial-gradient(circle, var(--accent) 0%, transparent 70%)',
            top: '-200px',
            right: '-200px',
            opacity: 0.15,
          }}
          animate={{ scale: [1, 1.1, 1], rotate: [0, 10, 0] }}
          transition={{ duration: 12, repeat: Infinity }}
        />
        <motion.div
          className="absolute w-[400px] h-[400px] rounded-full"
          style={{
            background: 'radial-gradient(circle, var(--primary) 0%, transparent 70%)',
            bottom: '-100px',
            left: '-100px',
            opacity: 0.08,
          }}
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      {/* Theme toggle */}
      <motion.button
        onClick={toggleTheme}
        className="fixed top-6 right-6 z-50 p-3 rounded-full bg-secondary hover:bg-muted transition-colors"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        {isDark ? <Sun size={20} /> : <Moon size={20} />}
      </motion.button>

      <div className="relative z-10 min-h-screen flex flex-col lg:flex-row">
        {/* Left: Hero with giant logo */}
        <motion.div
          className="flex-1 flex flex-col justify-center p-8 lg:p-16 xl:p-24"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          {/* Giant Logo Section */}
          <motion.div
            className="relative mb-12"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Logo glow effect */}
            <div className="absolute -inset-8 bg-accent/20 rounded-full blur-3xl" />
            <div className="absolute -inset-4 bg-accent/10 rounded-full blur-xl" />
            
            {/* Main logo container */}
            <div className="relative flex items-center gap-6">
              <motion.div
                className="relative w-24 h-24 lg:w-32 lg:h-32 xl:w-40 xl:h-40 rounded-2xl bg-primary flex items-center justify-center shadow-2xl"
                whileHover={{ rotate: [0, -5, 5, 0], scale: 1.05 }}
                transition={{ duration: 0.5 }}
              >
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/favicon-fgkTMEMM9Guo7qyjqKkEAp2AwLYrBL.svg"
                  alt="Yomitoki"
                  width={80}
                  height={80}
                  className="w-16 h-16 lg:w-20 lg:h-20 xl:w-24 xl:h-24 dark:invert"
                />
                {/* Corner accent */}
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-accent rounded-lg" />
              </motion.div>
              
              <div>
                <motion.h2
                  className="text-4xl lg:text-5xl xl:text-6xl font-black tracking-tight"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  YOMITOKI
                </motion.h2>
                <motion.p
                  className="text-lg lg:text-xl text-accent font-medium tracking-widest mt-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  読み解く
                </motion.p>
              </div>
            </div>
          </motion.div>

          {/* Headline */}
          <motion.div
            className="space-y-6 max-w-2xl"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h1 className="text-5xl lg:text-6xl xl:text-7xl font-black leading-[0.9] tracking-tight">
              <span className="block">AIプランを</span>
              <span className="block text-accent">記録し、</span>
              <span className="block">読み解く。</span>
            </h1>
            
            <p className="text-lg lg:text-xl text-muted-foreground leading-relaxed max-w-lg">
              プランは承認されたあと消えていく。
              <br />
              Yomitokiはその流れを受け止める場所。
            </p>
          </motion.div>

          {/* Feature pills */}
          <motion.div
            className="flex flex-wrap gap-3 mt-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
          >
            {['瞬間を捉える', 'パターンを解析', '意思決定を追跡'].map((feature, i) => (
              <motion.span
                key={feature}
                className="px-4 py-2 rounded-full bg-secondary text-sm font-medium border border-border"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + i * 0.1 }}
                whileHover={{ scale: 1.05, backgroundColor: 'var(--accent)', color: 'var(--accent-foreground)' }}
              >
                {feature}
              </motion.span>
            ))}
          </motion.div>
        </motion.div>

        {/* Right: Login panel */}
        <motion.div
          className="w-full lg:w-[480px] xl:w-[540px] bg-card border-l border-border flex items-center justify-center p-8 lg:p-12"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <div className="w-full max-w-sm">
            {/* Login header */}
            <motion.div
              className="mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <h3 className="text-2xl font-bold mb-2">ログイン</h3>
              <p className="text-muted-foreground text-sm">
                アカウントにアクセスして続ける
              </p>
            </motion.div>

            <motion.form
              onSubmit={handleSubmit}
              className="space-y-5"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <div className="space-y-2">
                <label className="text-sm font-medium">メールアドレス</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">パスワード</label>
                  <a href="#" className="text-xs text-accent hover:underline">
                    パスワードをお忘れですか？
                  </a>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <motion.button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 group"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {isLoading ? (
                  <span className="animate-pulse">読み解き中...</span>
                ) : (
                  <>
                    ログイン
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </motion.button>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-card px-3 text-muted-foreground">または</span>
                </div>
              </div>

              <motion.button
                type="button"
                className="w-full border border-border text-foreground py-3 rounded-lg font-medium hover:bg-secondary transition-all"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Passkeyでログイン
              </motion.button>
            </motion.form>

            <motion.p
              className="text-center text-sm text-muted-foreground mt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
            >
              アカウントをお持ちでないですか？{' '}
              <a href="#" className="text-accent font-medium hover:underline">
                新規登録
              </a>
            </motion.p>
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <motion.footer
        className="absolute bottom-4 left-8 text-xs text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        © 2024 YOMITOKI
      </motion.footer>
    </div>
  );
}
